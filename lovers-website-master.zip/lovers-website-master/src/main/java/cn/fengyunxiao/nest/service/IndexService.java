package cn.fengyunxiao.nest.service;

import org.springframework.stereotype.Service;

@Service
public class IndexService {

}
